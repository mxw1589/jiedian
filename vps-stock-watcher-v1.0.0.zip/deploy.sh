#!/usr/bin/env bash
set -euo pipefail

APP_DIR="/root/vmiss-stock-watcher"
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ "${EUID}" -ne 0 ]]; then
  echo "请使用 root 执行：sudo bash deploy.sh"
  exit 1
fi

if ! command -v node >/dev/null 2>&1; then
  echo "未检测到 Node.js。请先安装 Node.js 20 或更高版本，再重新运行本脚本。"
  exit 1
fi

NODE_MAJOR="$(node -p 'Number(process.versions.node.split(".")[0])')"
if [[ "${NODE_MAJOR}" -lt 20 ]]; then
  echo "当前 Node.js 版本低于 20：$(node --version)。请先升级 Node.js。"
  exit 1
fi

mkdir -p "${APP_DIR}"
cp -a "${SRC_DIR}/." "${APP_DIR}/"
cd "${APP_DIR}"

if [[ ! -f .env ]]; then
  cp .env.example .env
  chmod 600 .env
  echo "已创建 .env 示例文件；如需 Telegram 消息，请在 VPS 本地编辑 ${APP_DIR}/.env。"
fi

npm install --omit=dev
npx playwright install --with-deps chromium

NODE_BIN="$(command -v node)"
sed -e "s|/root/vmiss-stock-watcher|${APP_DIR}|g" \
    -e "s|__NODE_BIN__|${NODE_BIN}|g" \
    vmiss-stock-watcher.service > /etc/systemd/system/vmiss-stock-watcher.service

systemctl daemon-reload
systemctl enable --now vmiss-stock-watcher.service

echo
echo "库存监控服务已安装。"
echo "查看服务：systemctl status vmiss-stock-watcher --no-pager"
echo "查看日志：journalctl -u vmiss-stock-watcher -f"
echo "配置文件：${APP_DIR}/.env"
echo "状态文件：${APP_DIR}/state.json"
echo "注意：本服务只检查 yunyoo.cc 与 dedione.com 的 5 个指定商品，不访问 app.vmiss.com。"
