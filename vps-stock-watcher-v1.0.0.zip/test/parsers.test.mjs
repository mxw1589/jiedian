import test from "node:test";
import assert from "node:assert/strict";
import {
  extractHeadingSection,
  parseDediOneStatus,
  parseYunyooStatus,
} from "../lib/parsers.mjs";

const Y = "台湾彰化 TCVM - Nano";
const D1 = "20260520-LAX.VPS.INTL.1C1G20G-Special-12.99";
const D2 = "20260520-LAX.VPS.CN.1C1G20G-Special-12.99";

test("YUNYOO sold-out marker wins over generic purchase words", () => {
  assert.equal(parseYunyooStatus(`${Y}\n¥10.99 /MONTHLY\n售罄`), "out_of_stock");
});

test("YUNYOO explicit in-stock marker is accepted", () => {
  assert.equal(parseYunyooStatus(`${Y}\n¥10.99 /MONTHLY\n有货\n立即购买`), "in_stock");
});

test("YUNYOO missing exact product is unknown", () => {
  assert.equal(parseYunyooStatus("台湾彰化 TCVM - Mini\n有货"), "unknown");
});

test("DediOne 0 Available is out of stock", () => {
  assert.equal(parseDediOneStatus(`${D1}\n$12.99 Annually\n0 Available`, D1), "out_of_stock");
});

test("DediOne positive Available is in stock", () => {
  assert.equal(parseDediOneStatus(`${D1}\n$12.99 Annually\n3 Available`, D1), "in_stock");
});

test("DediOne out-of-stock detail page is out of stock", () => {
  assert.equal(parseDediOneStatus(`${D1}\nOut of Stock`, D1), "out_of_stock");
});

test("DediOne ambiguous inventory is unknown", () => {
  assert.equal(parseDediOneStatus(`${D1}\nAvailable soon`, D1), "unknown");
});

test("section extraction stops before the next product heading", () => {
  const body = `${D1}\n$12.99 Annually\n0 Available\n${D2}\n$12.99 Annually\n184 Available`;
  const section = extractHeadingSection(body, [D1, D2], D1);
  assert.match(section, /0 Available/);
  assert.doesNotMatch(section, /184 Available/);
  assert.equal(parseDediOneStatus(section, D1), "out_of_stock");
});
