import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { chromium } from "playwright";
import {
  extractHeadingSection,
  parseDediOneStatus,
  parseYunyooStatus,
} from "./lib/parsers.mjs";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
await loadDotEnv(path.join(__dirname, ".env"));

const CHECK_INTERVAL_MINUTES = clampInt(process.env.CHECK_INTERVAL_MINUTES, 60, 15, 1440);
const CHECK_TIMEOUT_MS = clampInt(process.env.CHECK_TIMEOUT_MS, 25000, 5000, 90000);
const STATE_FILE = process.env.STATE_FILE || path.join(__dirname, "state.json");
const TELEGRAM_BOT_TOKEN = String(process.env.TELEGRAM_BOT_TOKEN || "").trim();
const TELEGRAM_CHAT_ID = String(process.env.TELEGRAM_CHAT_ID || "").trim();

const YUNYOO_URL = "https://yunyoo.cc/cart?fid=5&gid=19";
const DEDIONE_URL = "https://dedione.com/store/special-vps-plans";

// Exact allowlist. app.vmiss.com is intentionally absent.
const ALLOWED_HOSTS = new Set(["yunyoo.cc", "www.yunyoo.cc", "dedione.com", "www.dedione.com"]);

const YUNYOO_PRODUCT = {
  key: "yunyoo-tw-changhua-tcvm-nano",
  merchant: "云悠 YUNYOO",
  name: "台湾彰化 TCVM - Nano",
  listingUrl: YUNYOO_URL,
  buyUrl: YUNYOO_URL,
  price: "¥10.99 / 月起",
  specs: [
    "💻 CPU：1 核 / Intel Xeon",
    "🧠 内存：256MB DDR4",
    "💾 存储：10GB SSD",
    "🚀 带宽：200Mbps / 1TB 双向",
    "🌐 IPv4：10 个端口",
  ],
};

const DEDIONE_PRODUCTS = [
  {
    key: "dedione-20260520-lax-intl",
    merchant: "DediOne",
    name: "20260520-LAX.VPS.INTL.1C1G20G-Special-12.99",
    listingUrl: DEDIONE_URL,
    buyUrl: "https://dedione.com/store/special-vps-plans/20260520-lax-vps-intl-1c1g20g-special-1299",
    price: "$12.99 / 年",
    specs: [
      "💻 CPU：1 vCore",
      "🧠 RAM：1GB",
      "💾 存储：20GB SSD",
      "🚀 流量：1TB / 月",
      "🌐 端口：1Gbps Dedicated",
      "📍 位置：Los Angeles, US",
      "🌐 IP：1 IPv4 + 2 IPv6",
    ],
  },
  {
    key: "dedione-20260520-lax-cn",
    merchant: "DediOne",
    name: "20260520-LAX.VPS.CN.1C1G20G-Special-12.99",
    listingUrl: DEDIONE_URL,
    buyUrl: "https://dedione.com/store/special-vps-plans/20260520-lax-vps-cn-1c1g20g-special-1299",
    price: "$12.99 / 年",
    specs: [
      "💻 CPU：1 vCore",
      "🧠 RAM：1GB",
      "💾 存储：20GB SSD",
      "🚀 带宽：100Mbps Unmetered",
      "🛣️ 线路：China Direct Optimized",
      "📍 位置：Los Angeles, US",
      "🌐 IP：1 IPv4 + 2 IPv6",
    ],
  },
  {
    key: "dedione-20260616-kc-cn",
    merchant: "DediOne",
    name: "20260616-KC.VPS.CN.1C1G30G-Special-12.99",
    listingUrl: DEDIONE_URL,
    buyUrl: "https://dedione.com/store/special-vps-plans/20260616-kc-vps-cn-1c1g30g-special-1299",
    price: "$12.99 / 年",
    specs: [
      "💻 CPU：1 vCore",
      "🧠 RAM：1GB",
      "💾 存储：30GB NVMe",
      "🚀 带宽：100Mbps Unmetered",
      "🛣️ 线路：China Direct Optimized",
      "📍 位置：Kansas City, US",
      "🌐 IP：1 IPv4 + 2 IPv6",
    ],
  },
  {
    key: "dedione-20250927-kc",
    merchant: "DediOne",
    name: "20250927-KC-Special-12.99",
    listingUrl: DEDIONE_URL,
    buyUrl: "https://dedione.com/store/special-vps-plans/20250927-kc-special-1299",
    price: "$12.99 / 年",
    specs: [
      "💻 CPU：1 vCore",
      "🧠 RAM：1GB",
      "💾 存储：20GB NVMe",
      "🚀 流量：2TB / 月",
      "🌐 端口：1Gbps Dedicated",
      "📍 位置：Kansas City, US",
      "🌐 IP：1 IPv4 + 2 IPv6",
    ],
  },
];

const PRODUCTS = [YUNYOO_PRODUCT, ...DEDIONE_PRODUCTS];

async function loadDotEnv(file) {
  try {
    const raw = await fs.readFile(file, "utf8");
    for (const line of raw.split(/\r?\n/)) {
      const match = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);
      if (!match || Object.prototype.hasOwnProperty.call(process.env, match[1])) continue;
      let value = match[2];
      if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
        value = value.slice(1, -1);
      }
      process.env[match[1]] = value;
    }
  } catch {
    // .env is optional. ChatGPT's separate in-app watch can still notify.
  }
}

function clampInt(raw, fallback, min, max) {
  const value = Number.parseInt(String(raw ?? ""), 10);
  return Number.isFinite(value) ? Math.min(max, Math.max(min, value)) : fallback;
}

function assertAllowedUrl(url) {
  const parsed = new URL(url);
  if (!ALLOWED_HOSTS.has(parsed.hostname)) {
    throw new Error(`Blocked non-allowlisted host: ${parsed.hostname}`);
  }
  return parsed;
}

function normalizeForMatch(value) {
  return String(value ?? "").replace(/\u00a0/g, " ").replace(/\s+/g, " ").trim();
}

async function readPageTextAndHeadings(page) {
  return page.evaluate(() => {
    const bodyText = document.body?.innerText || "";
    const headings = Array.from(document.querySelectorAll("h1,h2,h3,h4,h5"))
      .map((el) => (el.innerText || el.textContent || "").replace(/\s+/g, " ").trim())
      .filter(Boolean);
    const challenge = /just a moment|checking your browser|verify you are human|captcha|access denied/i.test(bodyText);
    return { bodyText, headings, challenge };
  });
}

async function navigateAndRead(page, url) {
  assertAllowedUrl(url);
  await page.goto(url, { waitUntil: "domcontentloaded", timeout: CHECK_TIMEOUT_MS });
  await page.waitForTimeout(1800);
  return readPageTextAndHeadings(page);
}

function sectionFor(data, productName, fallbackChars = 1800) {
  if (!data || data.challenge) return "";
  return extractHeadingSection(data.bodyText, data.headings, productName, fallbackChars);
}

async function collectStatuses() {
  const results = new Map(PRODUCTS.map((p) => [p.key, "unknown"]));
  let browser;

  try {
    browser = await chromium.launch({
      headless: true,
      args: ["--no-sandbox", "--disable-dev-shm-usage"],
    });
    const context = await browser.newContext({
      locale: "zh-CN",
      timezoneId: "Asia/Shanghai",
      viewport: { width: 1365, height: 900 },
    });
    const page = await context.newPage();
    page.setDefaultNavigationTimeout(CHECK_TIMEOUT_MS);
    page.setDefaultTimeout(CHECK_TIMEOUT_MS);

    try {
      const yunyooData = await navigateAndRead(page, YUNYOO_URL);
      const section = sectionFor(yunyooData, YUNYOO_PRODUCT.name, 1200);
      results.set(
        YUNYOO_PRODUCT.key,
        parseYunyooStatus(section, YUNYOO_PRODUCT.name),
      );
    } catch (error) {
      console.error(`[check] YUNYOO unknown: ${safeError(error)}`);
    }

    try {
      const dedioneData = await navigateAndRead(page, DEDIONE_URL);
      for (const product of DEDIONE_PRODUCTS) {
        const section = sectionFor(dedioneData, product.name, 1800);
        results.set(product.key, parseDediOneStatus(section, product.name));
      }
    } catch (error) {
      console.error(`[check] DediOne unknown: ${safeError(error)}`);
    }

    await context.close();
  } catch (error) {
    console.error(`[check] browser unavailable: ${safeError(error)}`);
  } finally {
    if (browser) {
      try { await browser.close(); } catch {}
    }
  }

  return results;
}

function safeError(error) {
  return String(error?.message || error || "unknown error").replace(/[\r\n]+/g, " ").slice(0, 300);
}

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, (char) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  })[char]);
}

function buildAlertMessage(product) {
  const specs = product.specs.map((line) => escapeHtml(line)).join("\n");
  const name = escapeHtml(product.name);
  const merchant = escapeHtml(product.merchant);
  const price = escapeHtml(product.price);
  const url = product.buyUrl; // Static direct order URL; intentionally no affiliate parameters.
  return [
    `<b>🔵 ${merchant} - 补货通知</b>`,
    "",
    `🟢 <b>${name}</b> 补货了！`,
    "",
    `💰 ${price}`,
    "📦 状态：有货",
    "",
    specs,
    "",
    `🛒 <a href="${escapeHtml(url)}">立即购买</a>`,
    escapeHtml(url),
    "",
    "⚡ 手慢无，速冲！",
  ].join("\n");
}

async function sendTelegram(product) {
  if (!TELEGRAM_BOT_TOKEN || !TELEGRAM_CHAT_ID) {
    console.warn("[notify] Telegram not configured; no external message sent.");
    return false;
  }

  const endpoint = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`;
  const response = await fetch(endpoint, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      chat_id: TELEGRAM_CHAT_ID,
      text: buildAlertMessage(product),
      parse_mode: "HTML",
      disable_web_page_preview: false,
    }),
    signal: AbortSignal.timeout(15000),
  });

  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload.ok !== true) {
    throw new Error(`Telegram API rejected message (${response.status})`);
  }
  return true;
}

async function loadState() {
  try {
    const parsed = JSON.parse(await fs.readFile(STATE_FILE, "utf8"));
    if (parsed && typeof parsed === "object" && parsed.items && typeof parsed.items === "object") return parsed;
  } catch {}
  return { version: 1, items: {} };
}

async function saveState(state) {
  await fs.mkdir(path.dirname(STATE_FILE), { recursive: true });
  const temp = `${STATE_FILE}.tmp`;
  await fs.writeFile(temp, JSON.stringify(state, null, 2), { mode: 0o600 });
  await fs.rename(temp, STATE_FILE);
}

async function processResults(results) {
  const state = await loadState();

  for (const product of PRODUCTS) {
    const status = results.get(product.key) || "unknown";
    if (status === "unknown") {
      console.log(`[state] ${product.name}: unknown; no notification.`);
      continue;
    }

    const previous = state.items[product.key] || { status: "unknown", alerted: false };

    if (status === "out_of_stock") {
      state.items[product.key] = {
        status: "out_of_stock",
        alerted: false,
        checkedAt: new Date().toISOString(),
      };
      console.log(`[state] ${product.name}: out_of_stock; silent.`);
      continue;
    }

    if (status === "in_stock") {
      if (previous.status !== "in_stock" || previous.alerted !== true) {
        try {
          const sent = await sendTelegram(product);
          state.items[product.key] = {
            status: "in_stock",
            alerted: sent,
            checkedAt: new Date().toISOString(),
            alertedAt: sent ? new Date().toISOString() : null,
          };
          if (sent) console.log(`[state] ${product.name}: restock alert sent.`);
        } catch (error) {
          // Keep alert pending so the next cycle retries; never send a run-status notification.
          state.items[product.key] = {
            status: "in_stock",
            alerted: false,
            checkedAt: new Date().toISOString(),
          };
          console.error(`[notify] ${product.name}: ${safeError(error)}`);
        }
      } else {
        state.items[product.key] = {
          ...previous,
          status: "in_stock",
          checkedAt: new Date().toISOString(),
        };
      }
    }
  }

  await saveState(state);
}

async function runOnce() {
  const results = await collectStatuses();
  await processResults(results);
}

async function main() {
  console.log(`[watcher] watching ${PRODUCTS.length} allowlisted products; interval=${CHECK_INTERVAL_MINUTES}m`);
  console.log("[watcher] app.vmiss.com and all other products are excluded.");
  const once = process.argv.includes("--once");

  do {
    try {
      await runOnce();
    } catch (error) {
      console.error(`[watcher] cycle failed: ${safeError(error)}`);
    }
    if (once) break;
    await new Promise((resolve) => setTimeout(resolve, CHECK_INTERVAL_MINUTES * 60 * 1000));
  } while (true);
}

main().catch((error) => {
  console.error(`[watcher] fatal: ${safeError(error)}`);
  process.exitCode = 1;
});
