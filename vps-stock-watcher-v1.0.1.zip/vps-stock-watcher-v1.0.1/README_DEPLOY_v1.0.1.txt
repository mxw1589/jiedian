指定 VPS 库存监控服务 v1.0.1

修复内容：
- 修复 v1.0.0 在 /root 解压时，deploy.sh 将 /root/. 复制到 /root/vmiss-stock-watcher/ 导致“cannot copy a directory into itself”的问题。
- 现在仅复制 watcher.mjs、package.json、.env.example、service、lib/、test/，不会复制整个源目录。
- 可从版本目录运行，也可从已解压到 /root 的目录运行；会保留已有 .env 和 state.json。

部署：
1. 上传 vps-stock-watcher-v1.0.1.zip 到 VPS 的 /root。
2. 执行：
   cd /root
   unzip -o vps-stock-watcher-v1.0.1.zip
   cd /root/vps-stock-watcher-v1.0.1
   sudo bash deploy.sh

部署成功后：
   systemctl status vmiss-stock-watcher --no-pager
   journalctl -u vmiss-stock-watcher -f

重要：
- 监控白名单仅 yunyoo.cc 和 dedione.com 的 5 个指定商品。
- 不会访问 app.vmiss.com。
- 默认每 60 分钟检查；只在明确确认有货时发送补货提醒。
- 本脚本不发送运行成功、失败或无货通知。
